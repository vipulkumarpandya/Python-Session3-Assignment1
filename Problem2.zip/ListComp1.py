a = input("Enter a string ")

lst=[ i.upper() for i in a ]

print (lst)
