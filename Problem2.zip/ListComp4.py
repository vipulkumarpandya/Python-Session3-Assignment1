a = input("Enter a number ")

lst=[[k] for i in range(2,int(a)) for k in range(i,i+3)]

print (lst)