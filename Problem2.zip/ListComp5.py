a = input("Enter a number ")

temp=[]
lst=[ [k,k+1,k+2,k+3] for k in range(2,int(a)) ]

print (lst)