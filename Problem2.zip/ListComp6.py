a = input("Enter a number ")

lst=[(k,i) for i in range(1,int(a)+1) for k in range(1,int(a)+1)]

print (lst)