a = input("Enter a string ")

lst=[ a[k-1]*int(i) for i in range(1,5) for k in range(1,len(a)+1)]

print (lst)