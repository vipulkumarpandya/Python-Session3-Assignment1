def function1(a):
    if a=='b':
        return True
    else:
        return False


def function2(a):
    if a == 'c':
        return True
    else:
        return False


def function3(a):
    if a == 'd':
        return True
    else:
        return False


def reduce1(a = []):
    prd = 1

    for i in a:
        prd = prd * int(i)

    print ("Reduce = ", prd)



