from FunctionLib import *

numStr = input ("Enter a list of Comma Separated numbers ")
numLst = numStr.split(",")

reduce1(numLst)

