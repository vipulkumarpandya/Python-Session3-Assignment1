from filterClassProblem2 import *



a = ['c','b','c','d','e']
f = "function2"

temp = filter1(f, a)

for i in temp:
    print(i)


