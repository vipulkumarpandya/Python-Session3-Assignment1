

class filter1:

    def __init__(self,func,iterobj = []):
        self.func1 = func
        self.iterobj1 = iterobj
        self.start = self.iterobj1[0]
        self.ctr=-1
        #print(self.start)

    def __iter__(self):
        return self


    def __next__(self):
        if self.ctr < len(self.iterobj1)-1:
            self.ctr +=1
            self.module = __import__('FunctionLib')
            self.func = getattr(self.module,self.func1)

            while (self.func(self.iterobj1[self.ctr]) == False):
                self.ctr+=1
                if self.ctr == len(self.iterobj1)-1:
                    raise StopIteration

            return self.iterobj1[self.ctr]
        else:
            raise StopIteration

